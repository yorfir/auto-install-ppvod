module.exports = {
    ok: 1,
    error: 0,
    totalsize: 300
}