var fs = require("fs"),path = require("path")
var MAX = 10;
var scanned = 0; 
function scan(mpath, srcformat, output) {		
		
	var self = this;
	var files = fs.readdirSync(mpath)
	//检测忽略列表
	var ignore = path.join(mpath, "ignore.txt");
	if(fs.existsSync(ignore)){
		return;
	}
	for (var x in files) {
		var file = path.join(mpath , files[x])
		//console.log("check file" + file)
		var stats;
		try{
			stats = fs.statSync(file)
		}catch(e){
			continue;
		}
		
		if (stats.isFile()) {
			if(files[x] == "main.mp4") continue;				
			if(files[x] == "91tmp.mp4") continue;
			
			
			var extname = path.extname(file)
			var basename = path.basename(file, extname)
						
			extname = extname.substring(1)
			
			var issupport = false;
			for (var i = 0; i < srcformat.length; i++) {					
				if (srcformat[i].toLowerCase() == extname.toLowerCase()) {						
					issupport = true;
					break;
				}
			};
			
			if (!issupport)
				continue;
			
			if(new Date().getTime() - stats.mtime <= 120*1000 || 
			   new Date().getTime() - stats.ctime <= 120*1000){
				//log.debug("文件", file, "最后改变时间小于60秒,临时忽略!");
				continue;
			}
			
			
			//log.debug(files[x]);
			issupport = true;
			try{
				fd = fs.openSync(file, "rs+")
				if(fd)
					fs.closeSync(fd);
				
			}catch(e){
				;;		
				issupport = false;
			}
			if (!issupport)
				continue;
			
			//console.log(file);
			var scanflag =  path.join(mpath ,basename + ".scan");
			if (fs.existsSync(scanflag))
				continue;
			
			fs.writeFileSync(scanflag, "y");
			var rpath= path.relative(input, mpath );
			var saveto = path.join(output , rpath	);
				
			var category = path.basename(path.dirname(file));
			var task = {
				outdir : output,
				saveto : saveto,
				category : category,
				orgfile : path.basename(file),
				rpath : path.join(rpath, basename),
				input : file
			}
			//log.debug(JSON.stringify(task));
			//console.log(typeof(process.send));
			//2016 05 08 增加 \n
			console.log(JSON.stringify(task) + "\n");
			scanned++;
			if(scanned >= MAX){
				process.exit(0);
			}
			continue;
		} else {
			//2015.12.05加入
			//如果存在.scan文件,那么忽略此目录								
			if(files[x] == "hls")
				continue;
			if(files[x] == "mp4")
				continue;
			if (!fs.existsSync(file + ".scan"))
				scan(file, srcformat, output)
				
		}
	}	
}
var input = process.argv[2];
var mpath = process.argv[2];
var srcformat = process.argv[3].split("|");
var output = process.argv[4];
//console.log("check", mpath, srcformat, output)
scan(mpath, srcformat, output);