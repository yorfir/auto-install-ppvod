var TimeoutQueue = require("./timeoutqueue");
var crypto = require('crypto');
var redis = require("redis");
var client;
function md5(str) {
    md5sum = crypto.createHash('md5');
    md5sum.update(str);
    return md5sum.digest('hex').toUpperCase();
}

function _print() {
    var out = "";
    for (var i = 0; i < arguments.length; i++)
        out += " " + arguments[i]
    if (process.env.DEBUG)
        console.log(out)
}
var log = {
    debug: _print,
    info: _print,
    error: _print
}

function randomString(len) {
    return crypto.randomBytes(Math.ceil(Math.max(8, len * 2)))
        .toString('base64')
        .replace(/[+\/]/g, '')
        .slice(0, len);
}
function VPath(opts) {
    this._processor = {};
    this._queue = new TimeoutQueue(120 * 1000);
    this.opts = opts;

    client = redis.createClient()
}

/**
 * @param tokenSuff 随机数尾缀
 */
VPath.prototype.regist = function (type, proc, timeout, contentType, tokenSuff) {
    this._processor[type] = {
        proc: proc,
        contentType: contentType,
        suff: tokenSuff,
        timeout: timeout
    }

    // log.debug(type, this._processor)
}

VPath.prototype.destroy = function () {
    this._queue.destroy();
    this._processor = null;
}
VPath.prototype.build = function (type, path, callback) {
    var self = this;
    if (!this._processor[type]) {
        log.error("No", type, " registered.");
        callback(null)
        return null;
    }
    
    if (this._processor[type].timeout == 0) {
        var key = type + path;
        var id = md5(key);
        if (this._processor[type].suff)
            id += this._processor[type].suff;
        self._queue.get(id, function (value) {
            if (!value) {
                var vpath = {
                    id: id,
                    vpath: self.opts.prefix + id,
                    type: type,
                    path: path,
                }
                self._queue.push(id, vpath, self._processor[type].timeout);
                value = vpath;
                log.debug("===================================1",id)
            }else
                log.debug("===================================2",id)

            callback(value);

        })
    } else {

        var id = randomString(8);
        if (this._processor[type].suff)
            id += this._processor[type].suff;
        var vpath = {
            id: id,
            vpath: this.opts.prefix + id,
            type: type,
            path: path,
        }
        this._queue.push(id, vpath, this._processor[type].timeout);
        callback(vpath);
    }
}

VPath.prototype.process = function (vpath, res, req) {
    // log.debug("vpath process", vpath)
    var me = this;
    var self = this;
    this._queue.get(vpath, function (value) {
        if (!value) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end("not found(1)");
            return;
        }
        value.req = req;
        value.res = res;
        log.debug("vpath process", vpath, value.type);
        self._processor[value.type].proc(value, function (err, content) {
            if (err) {
                log.error("error", err)

                res.writeHead(err.code, { 'Content-Type': 'text/plain' });
                if (!err.reason) err.reason = "unknown reason??"
                res.end(err.reason);
                return;
            }
            if (me._processor[value.type].contentType)
                res.writeHead(200, { 'Content-Type': me._processor[value.type].contentType });
            if (!content) {
                content = "";
                log.warn("vpathmgmt process content is empty.??")
            }
            res.end(content);
        })
    });

}

module.exports = VPath;