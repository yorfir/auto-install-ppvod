/**
 * videoserver集群
 */
var express = require('express'), fs = require("fs"), path = require('path');
var port = 2100;
var app = express();
var log4js = require('log4js'), log;
var crypto = require('crypto');
var querystring = require("querystring");
var m3u8parse = require('m3u8parse');
var hlsapp;

var Segment = require('m3u8parse').M3U8Segment;
var SIGN_TIMEOUT = 3600 * 2 * 1000;
// var danmu = require("./danmu");
var http = require("http")
var api_server = "http://127.0.0.1:2000/api"
var api_key = "v1"
var onFinished = require('on-finished')
var destroy = require('destroy');

// log4js.addAppender(log4js.appenders.file('logs/videoserver.log'), 'vidoeserver');
log4js.configure({
    appenders: [
        { type: 'console' },
        {
            "type": "file",
            "filename": "logs/videoserver.log",
            "maxLogSize": 20480,
            "backups": 5,
            "category": "vidoeserver"
        }
    ]
});
log = log4js.getLogger("vidoeserver");
function urlconcat(arg) {
    var url = "";
    for (var i = 0; i < arguments.length; i++) {
        var val = arguments[i];
        if (val == "") continue;
        //console.log(val.substring(0,1) )
        while (true) {

            if (val.substring(0, 1) != "/") break;
            val = val.substring(1, val.length);
        }
        // console.log(val)
        if (url == "") {
            url = val;
        } else {
            if (url.substring(url.length - 1, url.length) == "/")
                url += val
            else
                url += "/" + val
        }
    }
    return url;
}
process.on('uncaughtException', function (err) {
    console.log(err);
    // process.exit(15);
})
function build_url(path, query) {
    if (!query) query = {};
    query.key = api_key;
    return api_server + path + "?" + querystring.stringify(query)
}
var mgmt = {
    find: function (opts, callback) {
        http.get(build_url("/gettask", { id: opts._id }), function (res) {
            res.on('data', function (chunk) {
                callback(null, JSON.parse(chunk.toString()))
            })
        }).on('error', function (err) {
            log.error("error")
        })
    }
}



function fillTime(val) {
    if (val < 10)
        return "0" + val;
    else
        return "" + val;
}
//获得格式化时间 hh:mm:ss
function getFormatTime(time) {
    var h, m, s;
    h = fillTime(parseInt(time / 3600));
    m = fillTime(parseInt((time - 3600 * h) / 60));
    s = fillTime(time % 60);

    return h + ":" + m + ":" + s
}

/**
 * 
 91flv防盗链加密方法
我们内容采用JSON格式 UTF-8编码,示例如下：
{timestamp : 402232232323,ip : '172.16.7.33'}
 
对内容进行aes-256-cbc 格式编码，再从二进制编码为 16进制字符串。
 
按如上字符串，编码完成后的字符串:
85ac8afda9b5c0076f4a11f239ac6dfc0047c94fea0975edf259d902dd1795e1c41369d0366e5961e957cf398ae83033
 
 
作为 sign 参数传递至视频服务系统。
*/


function generateEncryptKey() {
    var d = new Date().getTime();
    var uuid = 'xxxxxxxxyyyyyyyy'.replace(/[xy]/g, function (c) {
        var r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c == 'x' ? r : (r & 0x7 | 0x8)).toString(16);
    });
    return uuid;
}
//加密
function enc(text, KEY) {
    var cipher = crypto.createCipher('aes-128-cbc', KEY)
    var crypted = cipher.update(text, 'utf8', 'hex')
    crypted += cipher.final('hex')
    return crypted;
}
//解密
function dec(text, KEY) {
    //log.debug("dec", text, KEY);
    var decipher = crypto.createDecipher('aes-128-cbc', KEY)
    try {
        var dec = decipher.update(text, 'hex', 'utf8')
        dec += decipher.final('utf8')
        return dec;
    } catch (e) {
        return null;
    }
}

function processAD(index, insertIndex, spgg, key) {
    log.debug("插入位置", insertIndex, "/", index.segments.length);
    var adsegment = { duration: 15, title: '', uri: spgg, discontinuity: true }

    adsegment.key = {
        METHOD: "NONE"
    }

    var msegment = new Segment(adsegment.uri, adsegment, 10000);


    if (insertIndex == index.segments.length - 1) {
        index.segments.push(msegment);
    }
    else {
        if (key)
            index.segments[insertIndex].key = key;
        index.segments[insertIndex].discontinuity = true;

        index.segments.splice(insertIndex, 0, msegment);
    }
}
//处理m3u8
function checkm3u8(req, res, next) {

    var self = _myserver;
    var rootdir = self.opts.root;

    //如果是顶级列表那么重新生成
    //log.debug("parse m3u8", path.join(rootdir, req.path));
    var m3u8file = path.join(rootdir, decodeURI(req.path));
    if (!fs.existsSync(m3u8file)) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end(req.path + "not found.")
        return;
    }
    try {
        var stream = fs.createReadStream(m3u8file);
        var KeyInfo = null;
        m3u8parse(stream, function (err, index) {
            if (err) {
                log.error("m3u8parse error!", err);
                res.end("m3u8parse error");
                return;
            }
            if (typeof (index.programs) == 'undefined') {
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                res.end("m3u8 parse error.");
                return;
            }


            var domainprefix = self.opts.domain;
            if (domainprefix && domainprefix != "") {
                if (domainprefix.indexOf("http://") < 0 && domainprefix.indexOf("https://") < 0)
                    domainprefix = "http://" + domainprefix;
                if (domainprefix.substring(domainprefix.length - 1, 1) == "/")
                    domainprefix = domainprefix.substring(0, domainprefix.length - 1)
                if (self.opts.port != "80" && (!self.opts.cdn_domain || self.opts.cdn_domain == ""))
                    domainprefix += ":" + self.opts.port;
            }
            if (domainprefix && domainprefix != "")
                domainprefix = domainprefix + "/";
            var programs = index.programs;

            domainprefix = ""; //全部用相对路径
            if (self.opts.cdn_domain && self.opts.cdn_domain != "")
                domainprefix = self.opts.cdn_domain;
            //log.debug("m3u8 programs " + JSON.stringify(programs));
            if (typeof (programs["1"]) != 'undefined') {
                for (var i = 0; i < programs["1"].length; i++) {
                    //log.debug("domainprefix" + domainprefix);
                    var queryinfo = req.query;
                    if (!queryinfo)
                        queryinfo = {}

                    if (self.opts.playkeyid &&
                        (typeof (self.opts.p2p) == 'undefined' || self.opts.p2p == 0))
                        queryinfo.sign = self.getSign(req.connection.remoteAddress);
                    // if (domainprefix && domainprefix != "")
                    // index.programs["1"][i].uri = domainprefix.substring(0, domainprefix.length - 1) + req.path.replace(/index.m3u8/, "") + index.programs["1"][i].uri + signinfo;
                    // else
                    index.programs["1"][i].uri = index.programs["1"][i].uri + "?" + querystring.stringify(queryinfo);
                    index.programs["1"][i].uri = index.programs["1"][i].uri.replace(/\\/g, "/");
                }
                res.end(index.toString());
            } else { //二级列表
                var segments = index.segments;

                var rpath = req.path.replace(/index.m3u8/, "");
                var tsspy = 0;
                if (_myserver.opts.tsspy && _myserver.opts.tsspy == 1) {
                    tsspy = 1;
                    log.debug("ts伪装开启")
                }
                //计算总的时长
                var playtime = {
                    start: (req.query.start ? req.query.start : 0),
                    end: (req.query.end ? req.query.end : 100 * 3600)
                }
                if (req.regsign) {
                    playtime.start = req.reqsign.start;
                    playtime.end = req.reqsign.end;
                }

                var curtime = 0;
                var newsegments = [];
                for (var i = 0; i < segments.length; i++) {
                    // log.debug(JSON.stringify(segments[i]));

                    curtime += segments[i].duration;
                    if (curtime < playtime.start) continue;
                    if (curtime > playtime.end) continue;
                    if (newsegments.length == 0 && i != 0) { //增加 key
                        if (typeof (segments[0].key) != 'undefined') {
                            if (domainprefix) {
                                segments[0].key.uri = urlconcat(domainprefix, rpath, segments[0].key.uri.replace(/"/g, ""), signinfo);
                                segments[0].key.uri = "\"" + segments[i].key.uri + "\""
                            }
                            segments[i].key = segments[0].key
                        }
                    }
                    newsegments.push(segments[i]);
                    //log.debug("==============", segments[i].key, typeof(segments[i].key));
                    var signinfo = "";

                    if (self.opts.playkeyid &&
                        (typeof (self.opts.p2p) == 'undefined' || self.opts.p2p == 0))
                        signinfo = "?sign=" + self.getSign(req.connection.remoteAddress);
                    var tsfile = segments[i].uri;
                    if (tsspy == 1) {
                        // log.debug("tsfile", tsfile)
                        tsfile = tsfile.replace(/\.ts/, ".js");
                    }
                    if (domainprefix) {
                        segments[i].uri = urlconcat(domainprefix, rpath, tsfile);
                        // segments[i].uri = segments[i].uri.replace(/\/\//, "/");
                    } else {
                        segments[i].uri = tsfile
                    }

                    if (typeof (segments[i].key) != 'undefined' && domainprefix) {
                        segments[i].key.uri = domainprefix + rpath + segments[i].key.uri.replace(/"/g, "") + signinfo;
                        segments[i].key.uri = "\"" + segments[i].key.uri + "\""

                    }


                }
                index.segments = newsegments;
                KeyInfo = index.segments[0].key;
                if (self.opts.spgg_tou && self.opts.spgg_tou != "") {
                    processAD(index, 0, self.opts.spgg_tou, KeyInfo);
                }

                if (self.opts.spgg && self.opts.spgg != "") {
                    var insertIndex = Math.floor(Math.random() * (index.segments.length - 1));//0-23 
                    processAD(index, insertIndex, self.opts.spgg, KeyInfo);
                }

                if (self.opts.spgg_wei && self.opts.spgg_wei != "") {
                    processAD(index, index.segments.length - 1, self.opts.spgg_wei, KeyInfo);
                }


                //log.debug(index.toString());
                res.end(index.toString());
            }
        });
    } catch (e) {
        log.error(e);
        res.end(e.toString());
    }

}


//处理m3u8
function checkxml(req, res, next) {

    var self = _myserver;
    var rootdir = self.opts.root;

    //如果是顶级列表那么重新生成
    //log.debug("parse m3u8", path.join(rootdir, req.path));
    var file = path.join(rootdir, decodeURI(req.path));

    if (!fs.existsSync(file)) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end(req.path + "index.xml not found.")
        return;
    }

    if (self.opts.playkeyid) {
        signinfo = "?sign=" + self.getSign(req.connection.remoteAddress);
        var content = fs.readFileSync(file).toString();
        //log.debug("kk2" + content);
        content = content.replace(/index\.m3u8/g, "index.m3u8" + signinfo);
        res.end(content);
    } else
        next();

}

//防盗链预处理
function checkrequest(req, res, next) {
    var self = _myserver;
    var refer = self.opts.refer;
    if (!req.headers["user-agent"]) {
        next();
        return;
    }
    //log.debug("request path:" + req.path);	
    //验证refer
    if (req.headers["user-agent"].indexOf("Android") > 0 ||
        req.headers["user-agent"].indexOf("android") > 0) {
        next();
        return;
    }

    var needCheck = false;
    var checkfile = [];
    if (self.opts.protfile && self.opts.protfile != "") {
        checkfile = checkfile.concat(self.opts.protfile.split("|"));
    } else {
        checkfile = checkfile.concat(['.m3u8', '.key', '.ts']);
    }
    // log.debug("防盗链检测列表:", checkfile.join(","));
    for (var i = 0; i < checkfile.length; i++) {
        if (req.path.indexOf(checkfile[i]) >= 0) {
            needCheck = true;
            break;
        }
    }
    //忽略
    if (!needCheck) {
        next();
        return;
    }

    if (refer && refer != "") {
        if (!req.headers.referer) {
            res.writeHead(401, { 'Content-Type': 'text/plain' });
            res.end("unauthorized access(referer)");
            return;
        }
        var referary = refer.split("|");
        var exist = false;
        referary.forEach(function (val, idx, ary) {
            //log.debug("refer:" + req.headers.referer + "/" + val + "  " + req.headers.referer.indexOf(val) );
            if (req.headers.referer.indexOf(val) >= 0)
                exist = true;
        });
        if (!exist) {
            res.writeHead(401, { 'Content-Type': 'text/plain' });
            res.end("unauthorized access(referer)");
            return;
        }
    }

    //log.debug(self.opts.playkeyid);
    if (self.opts.playkeyid && self.opts.playkeyid != "") {
        if (!req.query.sign || req.query.sign == "") {
            res.writeHead(401, { 'Content-Type': 'text/plain' });
            res.end("unauthorized access(urlsign)!")
            return;
        }
        var reqinfo = "";
        try {
            reqinfo = dec(req.query.sign, self.opts.playkeyid);
            reqinfo = querystring.parse(reqinfo);
            if (typeof (reqinfo.timestamp) == 'undefined') {
                res.writeHead(401, { 'Content-Type': 'text/plain' });
                res.end("sign error(1)");
                return;
            }
            //验证时间
            var date = new Date(parseInt(reqinfo.timestamp));

            if (new Date().getTime() - date.getTime() >= SIGN_TIMEOUT) {
                log.error(req.path + " time out...");
                res.writeHead(403, { 'Content-Type': 'text/plain' });
                res.end("url time out")
                return;
            }

            //log.debug("时间验证通过!")

            /**
            //ip认证
            if(reqinfo.ip != req.connection.remoteAddress){
                log.error("ip not match.", reqinfo.ip , req.connection.remoteAddress);
                res.writeHead(403, {'Content-Type': 'text/plain'});
                res.end("unauthorized access(-3)")
                return;
            }
            **/


            //log.debug("签名验证通过");

            req.reqsign = reqinfo;
        } catch (e) {
            reqinfo = null;
            log.error(e);
            res.writeHead(401, { 'Content-Type': 'text/plain' });
            res.end("sign error(-1)")
            return;
        }

    }

    next();
}



function procShare(req, res, next) {
    var self = _myserver;
    mgmt.find({ _id: req.params.path }, function (err, docs) {
        if (err || docs.length <= 0) {
            res.end("error");
            return;
        }
        var str = querystring.stringify({ timestamp: new Date().getTime(), ip: req.connection.remoteAddress })
        var sign = enc(str, self.opts.playkeyid);
        var picpath = self.opts.convertparam_pic.split("|");
        var sptoutime = self.opts.spgg_tou_time;
        if (!sptoutime || sptoutime == "")
            sptoutime = 15;
        var prefix = "http://" + req.hostname + ":" + _myserver.opts.port + "/";
        if (!_myserver.opts._myserver || _myserver.opts._myserver == "")
            prefix = ""
        var playtime = 0;
        if (docs[0].metadata)
            playtime = docs[0].metadata.time;
        playtime = getFormatTime(playtime);
        var mp4name = path.basename(docs[0].rpath.replace(/\\/g, "/"));
        res.render("share", {
            prefix: prefix, playtime: playtime, id: docs[0]._id, pic: docs[0].rpath.replace(/\\/g, "/") + "/1.jpg",
            ad_l: self.opts.ad_l, ad_r: self.opts.ad_r,
            ad_d: self.opts.ad_d, ad_u: self.opts.ad_u,
            starttime: sptoutime,
            title: path.basename(docs[0].orgfile, path.extname(docs[0].orgfile)),
            url: docs[0].rpath.replace(/\\/g, "/") + "/index.m3u8?sign=" + sign,
            torrent: prefix + "torrents/" + docs[0]._id + ".torrent",
            infoHash: docs[0].infoHash,
            xml: docs[0].rpath.replace(/\\/g, "/") + "/index.xml?sign=" + sign,
            mp4: docs[0].rpath.replace(/\\/g, "/") + "/mp4/" + mp4name + ".mp4?sign=" + sign,
            adsense: self.opts.adsense
        });
    });

    return;
}

var _myserver = {
    config: function (opts) {
        this.opts = opts;
    },
    getSign: function (ip) {
        var str = querystring.stringify({ timestamp: new Date().getTime(), ip: ip, uuid: generateEncryptKey() })
        return enc(str, this.opts.playkeyid);
    },
    getconfig: function (callback) {
        //获取配置文件
        var cfg = fs.readFileSync(path.join(process.cwd(), "config.ini")).toString();
        var ary = /apikey = (\w+)/.exec(cfg);
        if (!ary) {
            log.warn("no api_key set");
            callback("no api kei");
            return;
        }

        api_key = ary[1];
        var request = http.get(build_url("/getconfig", {}), function (res) {
            res.on('data', function (chunk) {

                var config = {}
                try {
                    config = JSON.parse(chunk.toString());
                } catch (e) {
                    log.error(e);
                }
                config.isdemo = config.dm
                config.port = 12100;
                if (config.server_port && config.server_port != "")
                    config.port = parseInt(config.server_port);

                config.port = 12100;
                config.root = config.srcfilepath;
                if (config.video_saveto && config.video_saveto != "")
                    config.root = config.video_saveto;

                config.domain = config.split_vprefix
                if (config.cdn_domain && config.cdn_domain != "")
                    config.domain = config.cdn_domain
                callback(null, config);
            })
        })
        request.on('error', function (err) {
            log.warn(err);
            callback(err)
        });
    },
    start: function () {

        var self = this;
        hlsapp = express();
        var webpage = path.join(process.cwd(), 'public');
        hlsapp.use("/html", express.static(webpage));

        hlsapp.set('views', path.join(process.cwd(), 'views'));
        hlsapp.set('view engine', 'ejs');
        hlsapp.use('/share/:path', procShare);

        if (this.opts.isdemo == false &&
            (typeof (this.opts.p2p) == 'undefined' || this.opts.p2p == 0)) {
            log.info("配置防盗链功能");
            hlsapp.all("*", checkrequest);
        }
        //启用p2p 需要取消 防盗链
        // if (typeof(this.opts.p2p) != 'undefined' || this.opts.p2p != 1) {
        hlsapp.all(/\s*index.xml/, checkxml);
        hlsapp.all(/\s*index.m3u8/, checkm3u8);
        if (this.opts.tsspy == 1 && false) {
            log.info("配置TS伪装");
            hlsapp.get(/\s*.ts/, function (req, res, next) {
                //改变 content-type
                res.setHeader("Content-Type", "text/javascript; charset=UTF-8");
                next();
            });
            //处理 ts 伪装
            hlsapp.get("/*", function (req, res, next) {
                // log.debug("xxxxxxxxxxx", req.path);
                if (req.path.indexOf("/html") > 0 || req.path.indexOf("socket.io") > 0 || req.path.indexOf("/share") > 0) {
                    next();
                    return;
                }
                if (req.path.indexOf(".js") > 0) {

                    var tsfile = path.join(self.opts.root, req.path.replace(/\.js/, ".ts"));
                    // log.debug("read ts as js",  tsfile);
                    var readStream = fs.createReadStream(tsfile);
                    readStream.pipe(res);
                    onFinished(res, function (err, res) {
                        if (readStream) destroy(readStream)
                    })
                    return;
                };
                next();
            })
        }

        hlsapp.use(express.static(self.opts.root));

        //try{
        //固定端口 12100
        self.server = hlsapp.listen(self.opts.port, "127.0.0.1", function () {
            log.info("视频服务器已经启动!" + self.opts.port)
        });
        self.server.on('error', function () {
            log.error("视频服务器启动失败,可能端口被占用!")
        });

    },
    stop: function () {
        if (this.server)
            this.server.close();
        this.server = null;

        if (this.btserver)
            this.btserver.close();
        log.info("视频服务已经停止!")
    }
}

var prepare = function () {
    _myserver.getconfig(function (err, config) {
        if (err) {
            setTimeout(prepare, 1000);
            return;
        }
        log.debug(config.root)
        _myserver.config(config);
        _myserver.start();
    });
}
prepare();



// module.exports = _myserver;

