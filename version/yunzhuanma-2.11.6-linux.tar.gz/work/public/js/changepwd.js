function modifypwd(){	
	if($"#pwd1")
}