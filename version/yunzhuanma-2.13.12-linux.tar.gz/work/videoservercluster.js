var express = require('express'), fs = require("fs"), path = require('path');
var port = 2100;
var app = express();
var crypto = require('crypto');
var querystring = require("querystring");
var m3u8parse = require('m3u8parse');
var hlsapp;
var exec = require('child_process').exec, child;
var Segment = require('m3u8parse').M3U8Segment;
var SIGN_TIMEOUT = 3600 * 2 * 1000;
// var danmu = require("./danmu");
var http = require("http")
var crypto = require('crypto');
var URL = require("url");
var m3u8cache = {}
var VPath = require("./vpathmgmt");
var redis = require("redis"),
    client = redis.createClient();
var vpathMgmt;
var async = require("async");
function md5(str) {
    md5sum = crypto.createHash('md5');
    md5sum.update(str);
    return md5sum.digest('hex').toUpperCase();
}
// log4js.addAppender(log4js.appenders.file('logs/videoserver.log'), 'vidoeserver');


function randomString(len) {
    return crypto.randomBytes(Math.ceil(Math.max(8, len * 2)))
        .toString('base64')
        .replace(/[+\/]/g, '')
        .slice(0, len);
}

function _print() {
    var out = "";
    for (var i = 0; i < arguments.length; i++)
        out += " " + arguments[i]
    if (process.env.DEBUG)
        console.log(out)
}
var log = {
    debug: _print,
    info: _print,
    error: _print
}
function urlconcat(arg) {
    var url = "";
    for (var i = 0; i < arguments.length; i++) {
        var val = arguments[i];
        if (val == "") continue;
        //console.log(val.substring(0,1) )
        while (true) {

            if (val.substring(0, 1) != "/") break;
            val = val.substring(1, val.length);
        }
        // console.log(val)
        if (url == "") {
            url = val;
        } else {
            if (url.substring(url.length - 1, url.length) == "/")
                url += val
            else
                url += "/" + val
        }
    }
    return url;
}
process.on('uncaughtException', function (err) {
    console.log(err);
    // process.exit(15);
})

function fillTime(val) {
    if (val < 10)
        return "0" + val;
    else
        return "" + val;
}
//获得格式化时间 hh:mm:ss
function getFormatTime(time) {
    var h, m, s;
    h = fillTime(parseInt(time / 3600));
    m = fillTime(parseInt((time - 3600 * h) / 60));
    s = fillTime(time % 60);

    return h + ":" + m + ":" + s
}

/**
 * 
 91flv防盗链加密方法
我们内容采用JSON格式 UTF-8编码,示例如下：
timestamp=402232232323&ip=172.16.7.33
 
对内容进行aes-256-cbc 格式编码，再从二进制编码为 16进制字符串。
 
按如上字符串，编码完成后的字符串:
85ac8afda9b5c0076f4a11f239ac6dfc0047c94fea0975edf259d902dd1795e1c41369d0366e5961e957cf398ae83033
 
 
作为 sign 参数传递至视频服务系统。
*/


function generateEncryptKey() {
    var d = new Date().getTime();
    var uuid = 'xxxxxxxxyyyyyyyy'.replace(/[xy]/g, function (c) {
        var r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c == 'x' ? r : (r & 0x7 | 0x8)).toString(16);
    });
    return uuid;
}

//加密
function enc(text, KEY) {
    var cipher = crypto.createCipher('aes-128-cbc', KEY)
    var crypted = cipher.update(text, 'utf8', 'hex')
    crypted += cipher.final('hex')
    return crypted;
}
//解密
function dec(text, KEY) {
    //log.debug("dec", text, KEY);
    var decipher = crypto.createDecipher('aes-128-cbc', KEY)
    try {
        var dec = decipher.update(text, 'hex', 'utf8')
        dec += decipher.final('utf8')
        return dec;
    } catch (e) {
        return null;
    }
}

function processAD(index, insertIndex, spgg, key) {
    log.debug("插入位置", insertIndex, "/", index.segments.length);
    var adsegment = { duration: 15, title: '', uri: spgg, discontinuity: true }

    adsegment.key = {
        METHOD: "NONE"
    }

    var msegment = new Segment(adsegment.uri, adsegment, 10000);


    if (insertIndex == index.segments.length - 1) {
        index.segments.push(msegment);
    }
    else {
        if (key)
            index.segments[insertIndex].key = key;
        index.segments[insertIndex].discontinuity = true;

        index.segments.splice(insertIndex, 0, msegment);
    }
}

//根据请求获取rootdir
function getRootDir(opts, req) {
    for (var i = 0; i < opts.outputdirs.length; i++) {
        var m3u8file = path.join(opts.outputdirs[i], decodeURI(req.newpath ? req.newpath : req.path));
        if (fs.existsSync(m3u8file)) {
            // log.debug("request" + m3u8file + "," + req.path + " rootdir" + decodeURI(req.newpath ? req.newpath : req.path));
            return opts.outputdirs[i];
        }
    }

    return null;
}

function getRealFileInfo(reqfile) {
    if (reqfile.indexOf("?") >= 0)
        reqfile = reqfile.substring(0, reqfile.indexOf("?"));
    if (API._realfileCache[reqfile])
        return API._realfileCache[reqfile];
    var outputdirs = API.opts.outputdirs;

    for (var i = 0; i < outputdirs.length; i++) {
        var file = path.join(outputdirs[i], decodeURI(reqfile));
        // log.debug("getRealFileInfo", file)
        if (fs.existsSync(file)) {
            API._realfileCache[reqfile] = { exist: true, file: file, dir: outputdirs[i] }
            // log.debug("request -->" + file + "," + path + " rootdir" + decodeURI(reqfile));
            return API._realfileCache[reqfile];
        }
    }
    //API._realfileCache[reqfile] = { exist: false }
    return { exist: false };
}


function procShare(req, res, next) {
    // log.debug(req.path, req.params)
    var self = API;
    client.get("video_" + req.params.path, function (err, data) {
        if (!data) {
            res.setHeader("Content-Type", "text/html; charset=utf-8")
            res.end("视频已经被移除!" + req.params.path);
            return;
        }

        data = JSON.parse(data);
        // console.log("video data", data)
        var docs = [data];
        var str = querystring.stringify({ timestamp: new Date().getTime(), ip: req.connection.remoteAddress })
        var sign = enc(str, self.opts.playkeyid);
        var picpath = self.opts.convertparam_pic.split("|");
        var sptoutime = self.opts.spgg_tou_time;
        if (!sptoutime || sptoutime == "")
            sptoutime = 15;
        var prefix = "http://" + API.opts.split_vprefix + ":" + API.opts.port + "/";
        // if (!API.opts._myserver || API.opts._myserver == "")
        // prefix = ""
        var playtime = 0;
        if (docs[0].metadata)
            playtime = docs[0].metadata.time;
        playtime = getFormatTime(playtime);
        var mp4name = path.basename(docs[0].rpath.replace(/\\/g, "/"));
        var requestToken = "tp" + randomString(8);

        //无防盗链 token 
        if (API.opts.urltimeout == 0) {
            requestToken = "pm" + docs[0]._id;
            log.debug("set permtoken_ token", requestToken);
        }

        var redirecturl = self.opts.redirecturl;
        if (!redirecturl) {
            redirecturl = self.opts.split_vprefix;
        }
        var shareOutput = {
            prefix: prefix, playtime: playtime, id: docs[0]._id, pic: docs[0].rpath.replace(/\\/g, "/") + "/1.jpg",
            ad_l: self.opts.ad_l, ad_r: self.opts.ad_r,
            redirecturl: redirecturl,
            ad_d: self.opts.ad_d, ad_u: self.opts.ad_u,
            token: requestToken,
            starttime: sptoutime,
            title: path.basename(docs[0].orgfile, path.extname(docs[0].orgfile)),
            url: docs[0].rpath.replace(/\\/g, "/") + "/index.m3u8",
            torrent: prefix + "torrents/" + docs[0].infoHash + ".torrent",
            infoHash: docs[0].infoHash,
            xml: docs[0].rpath.replace(/\\/g, "/") + "/index.xml",
            refer: self.opts.refer ? self.opts.refer : "",
            mp4: docs[0].rpath.replace(/\\/g, "/") + "/mp4/" + mp4name + ".mp4",
            status: docs[0].result,
            adsense: self.opts.adsense
        }

        client.setnx(requestToken, JSON.stringify(shareOutput))
        if (API.opts.urltimeout > 0) {
            client.expire(requestToken, 10)
        }

        // log.debug("渲染", shareOutput)
        res.render("share2", shareOutput);

    });

    return;
}

function qrbuild(content, saveto, cwd, callback) {
    if (cwd) process.env["cwd"] = cwd;
    saveto = saveto.replace(/\\/g, "/")
    log.debug("生成qr", content, saveto);
    child = exec(binpath + " " + content + " " + saveto, process.env, function (error, stdout, stderr) {
        if (error) {
            //if(type == 0)
            log.debug("生成QR出现问题", error);;
            return;
        }
    });
    child.on('close', function () {
        if (callback) callback();
    });
}

function procerweima(req, res, next) {
    client.get("video_" + req.params.path, function (err, data) {
        var url = prefix + "/share/" + docs[0]._id;
        if (!data) {
            res.end("no such file");
            return;
        }
        var qrfile = path.join(req.qrsavedir, data._id + ".png")
        if (fs.existsSync(qrfile)) {
            res.sendFile(qrfile);

        } else {
            qrbuild(url, qrfile, req.qrsavedir, function () {
                res.sendFile(qrfile);
            });
        }
    });
}

var vpathType = {
    m3u8_l1: 1,
    m3u8_l2: 5,
    key: 8,
    indexxml: 10,
}
function _proc_indexxml(vpath, callback) {
    var file = vpath.path;
    if (file.indexOf("?") >= 0)
        file = file.substring(0, file.indexOf("?"));
    var realfileinfo = getRealFileInfo(file);
    if (realfileinfo.exist == false) {
        callback({ code: 404, reason: "file not found" });
        return;
    }
    var xmlfile = realfileinfo.file;
    // log.debug(xmlfile, file)
    var content = fs.readFileSync(xmlfile).toString();
    var idx1 = content.indexOf("<![CDATA[");
    var idx2 = content.indexOf("]]", idx1);
    var m3u8 = content.substring(idx1 + "<![CDATA[".length, idx2);
    var m3u8Ary = m3u8.split("|");
    var newout = [];
    var sfunc = [];
    function getM3u8(type, path) {
        return function (callback) {
            vpathMgmt.build(vpathType.m3u8_l2, path.dirname(file) + "/" + val, function (value) {
                newout.push(vpathM3u8.id)
                callback(null, newout)
            })
        }
    }
    m3u8Ary.forEach(function (val) {
        sfunc.push(getM3u8(vpathType.m3u8_l2, path.dirname(file) + "/" + val));
    })
    async.waterfall(sfunc, function (err, result) {
        // log.debug(content.replace(m3u8, newout.join("|")));
        callback(null, content.replace(m3u8, result.join("|")))
    })

}
function _proc_level2_m3u8(vpath, callback) {
    log.debug("_proc_level2_m3u8", vpath.path)
    var file = vpath.path;
    if (file.indexOf("?") >= 0)
        file = file.substring(0, file.indexOf("?"));
    var realfileinfo = getRealFileInfo(file);
    if (realfileinfo.exist == false) {
        callback({ code: 404, reason: "file not found" });
        return;
    }
    var m3u8file = realfileinfo.file;


    var stream = fs.createReadStream(m3u8file);
    var KeyInfo = null;
    m3u8parse(stream, function (err, index) {
        if (err) {
            callback({ code: 500, reason: "m3u8parse error" });
            return;
        }
        var segments = index.segments;
        var tmpPath = file;
        var rpath = ""
        if (API.opts.outputdirs.length > 1)
            rpath = "/VMDIR" + md5(realfileinfo.dir) + "/" + path.dirname(file);
        else
            rpath = path.dirname(file)
        var tsspy = "";
        if (API.opts.tsspy) {
            if (API.opts.tsspy == 1) //兼容之前的模式  
                tsspy = ".js";
            else if (API.opts.tsspy == 0)
                tsspy = "";
            else
                tsspy = API.opts.tsspy;
        }
        var domainprefix = API.getCDNPrefix(); //全部用相对路径
        log.debug("getdomain prefix", domainprefix);
        //计算总的时长
        var playtime = {
            start: (vpath.req.query.start ? vpath.req.query.start : 0),
            end: (vpath.req.query.end ? vpath.req.query.end : 100 * 3600)
        }
        if (vpath.req.reqign) {
            playtime.start = vpath.req.reqsign.start;
            playtime.end = vpath.req.reqsign.end;
        }
        // console.log(playtime, vpath);
        var curtime = 0;
        var newsegments = [];

        // log.debug("================", segments.length)
        for (var i = 0; i < segments.length; i++) {
            // log.debug(JSON.stringify(segments[i]));

            curtime += segments[i].duration;
            if (curtime < playtime.start) continue;
            if (curtime > playtime.end) continue;

            newsegments.push(segments[i]);
        }
        segments = newsegments;
        // console.log(index.segments[0].key);

        if (index.segments[0].key && index.segments[0].key.uri) {
            if (domainprefix != "")
                index.segments[0].key.uri = "\"" + urlconcat(domainprefix, rpath, "key.key") + "\"";
            else
                index.segments[0].key.uri = "\"/" + urlconcat(domainprefix, rpath, "key.key") + "\"";

        }
        segments[0].key = index.segments[0].key;
        // log.debug("================", segments.length)
        for (var i = 0; i < segments.length; i++) {

            var tsfile = segments[i].uri;
            if (tsspy != "") {
                // log.debug("tsfile", tsfile)
                tsfile = tsfile.replace(/\.ts/, tsspy);
            }
            if (domainprefix != "")
                segments[i].uri = urlconcat(domainprefix, rpath, tsfile);
            else
                segments[i].uri = "/" + urlconcat(domainprefix, rpath, tsfile);



        }
        index.segments = segments;
        KeyInfo = index.segments[0].key;
        if (API.opts.spgg_tou && API.opts.spgg_tou != "") {
            processAD(index, 0, API.opts.spgg_tou, KeyInfo);
        }

        if (API.opts.spgg && API.opts.spgg != "") {
            var insertIndex = Math.floor(Math.random() * (index.segments.length - 1));//0-23 
            processAD(index, insertIndex, API.opts.spgg, KeyInfo);
        }

        if (API.opts.spgg_wei && API.opts.spgg_wei != "") {
            processAD(index, index.segments.length - 1, API.opts.spgg_wei, KeyInfo);
        }


        //log.debug(index.toString());
        callback(null, index.toString());
    })

}

function vpathbuild(type, mpath) {
    return function (callback) {
        vpathMgmt.build(type, mpath, function (value) {

            callback(null, value)
        })
    }
}
function procinexprogram(idxprogram, query) {
    return function (vpathM3u8, callback) {
        idxprogram.uri = vpathM3u8.vpath.replace(/\\/g, "/");
        if (query.start) {
            idxprogram.uri = idxprogram.uri + "?" + querystring.stringify(query)
        }
        callback(null)
    }

}
function _proc_level1_m3u8(vpath, callback) {
    var self = API;
    var file = vpath.path;
    var realfileinfo = getRealFileInfo(file);
    if (realfileinfo.exist == false) {
        callback({ code: 404, reason: "file not found" });
        return;
    }
    var m3u8file = realfileinfo.file;

    var stream = fs.createReadStream(m3u8file);
    var KeyInfo = null;
    m3u8parse(stream, function (err, index) {
        if (err) {
            callback({ code: 500, reason: "m3u8parse error" });
            return;
        }
        if (typeof (index.programs) == 'undefined' ||
            typeof (index.programs["1"]) == 'undefined') {
            callback({ code: 500, reason: "programs parse error." });
            return;
        }
        var sfunc = [];
        for (var i = 0; i < index.programs["1"].length; i++) {
            //log.debug("domainprefix" + domainprefix);
            sfunc.push(vpathbuild(vpathType.m3u8_l2, path.dirname(file) + "/" + index.programs["1"][i].uri));
            sfunc.push(procinexprogram(index.programs["1"][i], vpath.req.query));

        }
        async.waterfall(sfunc, function (err, results) {
            // log.debug("dddddddddddddd", index.toString())
            callback(null, index.toString());
        })

    })
}

function procRequestToken(req, res, next) {
    client.get(req.params.token, function (err, value) {
        if (!value) {
            res.end("error code-1");
            return;
        }
        value = JSON.parse(value);
        vpathMgmt.build(vpathType.m3u8_l1, value.url, function (vpathM3u8) {
            if (!vpathM3u8) {
                res.end("error code -11");
                return;
            }

            log.info("build m3u8 by token", value.url, vpathM3u8.vpath)
            vpathMgmt.build(vpathType.indexxml, value.xml, function (vpathXml) {
                if (!vpathXml) {
                    res.end("error code -12");
                    return;
                }
                log.info("build xml by token", vpathXml, vpathXml.url, vpathXml.vpath)
                res.json({ xml: vpathXml.vpath, main: vpathM3u8.vpath });
                res.end();
            })

        })

    });

}
function getPrefix(config, req) {
    //拼装前缀
    var prefix = req.protocol + "://" + req.get("Host");
    if (config.ConverterMain.split_vprefix &&
        config.ConverterMain.split_vprefix != "") {
        domain = config.ConverterMain.split_vprefix;
        if (domain.indexOf("http://") < 0)
            domain = "http://" + domain;
        prefix = domain + ":" + config.ConverterMain.server_port;
        if (config.ConverterMain.server_port == "80")
            prefix = domain;
    } else {
        prefix = "";
    }

    return prefix;
}

function verifySign(playkeyid, sign, req) {
    if (!playkeyid || playkeyid == "") return true;
    if (!sign || sign == "") {
        return { code: 401, reason: "unauthorized access(urlsign)!" };
    }
    var reqinfo = "";
    try {
        reqinfo = dec(sign, playkeyid);
        reqinfo = querystring.parse(reqinfo);
        if (typeof (reqinfo.timestamp) == 'undefined') {
            return { code: 401, reason: "sign error(1)" };
        }
        //验证时间
        var date = new Date(parseInt(reqinfo.timestamp));

        if (new Date().getTime() - date.getTime() >= SIGN_TIMEOUT) {
            return { code: 403, reason: "Time out" };
        }

        req.reqsign = reqinfo;

        //log.debug("时间验证通过!")

        /**
        //ip认证
        if(reqinfo.ip != req.connection.remoteAddress){
            log.error("ip not match.", reqinfo.ip , req.connection.remoteAddress);
            res.writeHead(403, {'Content-Type': 'text/plain'});
            res.end("unauthorized access(-3)")
            return;
        }
        **/


        //log.debug("签名验证通过");
        return { code: 200 };
    } catch (e) {
        return { code: 403, reason: "sing error (-1)" };
    }


}
var API = {
    getCDNPrefix: function () { //多个,RR 策略
        if (!this.cdn_prefix) return "";
        if (this.cdn_prefix.length == 1) return this.cdn_prefix[0];
        this.mcdn_idx++;
        if (this.mcdn_idx >= this.cdn_prefix.length)
            this.mcdn_idx = 0;
        return this.cdn_prefix[this.mcdn_idx];
    },
    config: function (opts) {
        this.opts = opts;
        if (!opts.urltimeout)
            opts.urltimeout = 2;
        log.debug("页面超时", opts.urltimeout, "分钟")
        this.opts.outputdirs = this.opts.root.split("|");
        this.mcdn_idx = 0;
        // log.debug("domainprefix", domainprefix)
        var domainPrefix = API.opts.cdn_domain;
        if (domainPrefix && domainPrefix != "") {
            if (domainPrefix.indexOf("|") > 0)
                this.cdn_prefix = domainPrefix.split("|");
            else
                this.cdn_prefix = [domainPrefix];
        }
    },
    getSign: function (ip) {
        var str = querystring.stringify({ timestamp: new Date().getTime(), ip: ip, uuid: generateEncryptKey() })
        return enc(str, this.opts.playkeyid);
    },
    start: function () {
        vpathMgmt = new VPath({ prefix: "/ppvod/" });
        this._realfileCache = {};
        var self = this;
        hlsapp = express();
        var webpage = path.join(process.cwd(), 'public');
        hlsapp.use("/html", express.static(webpage));

        hlsapp.set('views', path.join(process.cwd(), 'views'));
        hlsapp.set('view engine', 'ejs');
        hlsapp.use('/share/:path', procShare);
        var qrsavedir = path.join(process.cwd(), "erweima");
        if (!fs.existsSync(qrsavedir))
            fs.mkdirSync(qrsavedir)
        hlsapp.use('/qrapi/:id', function (req, res, next) {
            prefix = getPrefix({ ConverterMain: self.opts }, req);
            req.qrsavedir = qrsavedir;
            req.prefix = prefix;
            procerweima(req, res, next);
        });
        /**
        if (process.env.LICENSE || this.opts.isdemo == false) {
            log.info("配置防盗链功能");
            // hlsapp.all("*", checkNeed);
            hlsapp.all("*", checkrefer);
            // hlsapp.all("*", checksign);
        } else {
            log.info("禁止防盗链");
        }
         */
        //启用p2p 需要取消 防盗链
        // if (typeof(this.opts.p2p) != 'undefined' || this.opts.p2p != 1) {


        hlsapp.all(/\s*(index.xml|index.m3u8)/, function (req, res, next) { //index.xml
            if (API.opts.playkeyid && API.opts.playkeyid != "") {
                var result = verifySign(API.opts.playkeyid, req.query.sign, req);
                if (result.code != 200) {
                    res.writeHead(result.code, result.reason);
                    res.end();
                    return;
                }
            }
            var proc = null;
            if (req.path.indexOf("index.m3u8") > 0) {
                if (/\d+kb\/hls\/index.m3u8/.test(req.path))
                    proc = _proc_level2_m3u8;
                else
                    proc = _proc_level1_m3u8;
            } else if (req.path.indexOf("index.xml") > 0) {
                proc = _proc_indexxml;
                // res.header("X-Accel-Redirect", "/protected/av.txt");
                // res.end();
                // return;
            }

            proc({ req: req, res: res, vpath: req.path, path: req.path }, function (err, content) {
                if (err) {
                    res.writeHead(err.code, { 'Content-Type': 'text/plain' });
                    res.end(err.reason);
                    return;
                }
                res.writeHead(200, { 'Content-Type': 'application/vnd.apple.mpegURL' });
                res.end(content);
            });

        });

        hlsapp.all("/token/:token", procRequestToken);
        // hlsapp.all("/ppvod/:vpath", procvpath);
        // log.debug("防盗时间", API.opts.urltimeout * 60 * 1000);
        vpathMgmt.regist(vpathType.indexxml, _proc_indexxml, API.opts.urltimeout * 60 * 1000);
        vpathMgmt.regist(vpathType.m3u8_l1, _proc_level1_m3u8, API.opts.urltimeout * 60 * 1000, 'application/vnd.apple.mpegURL', ".m3u8");
        vpathMgmt.regist(vpathType.m3u8_l2, _proc_level2_m3u8, API.opts.urltimeout * 60 * 1000, 'application/vnd.apple.mpegURL', ".m3u8");

        hlsapp.all("/ppvod/:vpath", function (req, res, next) {
            log.debug("/ppvod/vpath", req.params.vpath);
            vpathMgmt.process(req.params.vpath, res, req);
        })

        // hlsapp.all(/\s*index.m3u8/, procm3u8);
        // log.debug("ddddddddd", self.opts.outputdirs)
        if (self.opts.outputdirs) {
            self.opts.outputdirs.forEach(function (val) {
                hlsapp.use(express.static(val));
            })
        }

        //try{
        //固定端口 12100
        self.server = hlsapp.listen(self.opts.innerPort, "127.0.0.1", function () {

            log.info("视频服务器已经启动!" + self.opts.innerPort)
        });
        self.server.on('connection', function (socket) {
            socket.setTimeout(60 * 1000);
        });
        self.server.on('error', function () {
            log.error("视频服务器启动失败,可能端口被占用!")
        });

        var root = API.opts.root.split("|");



    },
    stop: function () {
        if (this.server)
            this.server.close();
        this.server = null;
        if (vpathMgmt)
            vpathMgmt.destroy();
        this._realfileCache = {};
        log.info("视频服务已经停止!")
    }
}
client.get("videoserver_config", function (err, data) {
    var config = JSON.parse(data);
    config.innerPort = process.argv[2];
    log.info("videoserver config...");
    API.config(config)
    API.start();
})
