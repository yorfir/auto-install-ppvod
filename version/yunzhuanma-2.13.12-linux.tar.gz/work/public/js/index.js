var express = require('express');
var fs = require("fs")
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res) {
  if(req.session.auth != 'ok')
	res.redirect('/login.html');
  else
	res.render('index');		
});

module.exports = router;
