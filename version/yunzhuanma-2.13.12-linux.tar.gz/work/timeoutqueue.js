/**
 * 超时队列
 */

var redis = require("redis");
var client;
function Queue(timeout) {
    this.timeout = timeout;
    this._queue = {}
    client = redis.createClient()
    this.handler = setInterval(this.check.bind(this), this.timeout)
}

Queue.prototype.push = function (key, value, timeout) {
    timeout = timeout ? timeout : this.timeout
    var cvalue = { time: new Date(), _value: value ,timeout : timeout };
    this._queue[key] = cvalue;
    client.setnx(key, JSON.stringify(value));
    if (timeout != 0) {
        client.expire(key, parseInt(timeout / 1000));
    }
}

Queue.prototype.get = function (key, callback) {
    var value = this._queue[key] ? this._queue[key]._value : null;;
    if (value) {
        callback(value);
        return;
    }
    client.get(key, function (err, data) {
        if (data)
            callback(JSON.parse(data));
        else
            callback(null)
    })
}

Queue.prototype.remove = function (key) {
    delete this._queue[key];
    client.del(key)
}

Queue.prototype.destroy = function () {
    this._queue = {};
    clearInterval(this.handler);
}


Queue.prototype.check = function () {
    var curdate = new Date().getTime();
    for (var x in this._queue) {
        if (this._queue[x].timeout == 0) continue;
        if (curdate - this._queue[x].time.getTime() > this._queue[x].timeout) {
            delete this._queue[x];

        }
    }

}

module.exports = Queue;